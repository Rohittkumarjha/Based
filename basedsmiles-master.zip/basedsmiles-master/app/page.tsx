import App from "./components/App"

export default function Home() {
	return (
		<div>
			<App />
		</div>
	)
}